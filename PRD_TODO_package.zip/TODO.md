# TODO.md (요약)
Phase 1-2-3 기반 전체 작업 목록은 별도 TODO.md 참고.
