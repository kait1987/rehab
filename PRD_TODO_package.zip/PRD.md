# PRD: REHAB 재활 운동 추천 서비스

## 1. Executive Summary
**Product Vision**: 사용자의 통증 부위에 따라 가장 안전하고 효과적인 재활 운동 코스를 자동 생성하는 서비스  
**Value Proposition**: 통증/부상 부위 기반 맞춤 재활 운동 + 근처 헬스장 추천 + 사용자의 상태 변화 추적  
**Target Launch**: MVP 기준 8~12주

## 2. Problem Statement
### Current State
- 일반 헬스장은 재활 장비 부족
- 재활 운동은 단계별 강도 조절이 필요한데 사용자 스스로 판단 어려움
- 개인별 통증·부상이 다른데도 동일한 루틴을 따라함 → 재부상 위험

### Desired State
- 사용자의 부위별 통증/부상 상태에 맞춘 재활 코스를 즉시 생성  
- 운동 강도 자동 조절  
- 근처에서 운동 가능한 헬스장 추천  
- 향후 웨어러블 기반 정밀 재활 데이터 활용

## 3. User Personas
### Persona: 부상 회복 중 직장인
- **Goals**: 안전하게 회복, 시간 절약  
- **Frustrations**: 어떤 운동이 안전한지 모름  
- **User Story**: “나는 내 통증에 맞는 운동만 골라보고 싶다.”

### Persona: 헬스장 사용자
- **Goal**: 가벼운 재활 후 운동 복귀

## 4. User Journey
1. 통증 부위 선택  
2. 세부 통증/상태 체크  
3. 재활 운동 코스 생성  
4. 근처 헬스장 추천  
5. 운동 후 리뷰 입력  
6. 기록 저장

## 5. Feature Requirements
### P0
| Feature | Description |
|--------|-------------|
| 재활 코스 생성 엔진 v1 | 하이브리드 템플릿 기반, 금기 운동 제거 |
| 헬스장 검색 | 네이버 API 기반 장소/운영시간 |
| 운동 템플릿 100개 | 4단계(안정/기본/발전/강화) |
| 리뷰 시스템 | 태그형 리뷰 |

### P1
| Feature | Description |
|--------|-------------|
| 템플릿 200개 확장 | 부위 50개 이상 |
| 사용자 프로필 | 통증·가동범위 기록 |
| 히스토리 | 주차별 기록 |

### P2
| Feature | Description |
|--------|-------------|
| AI 재활 코치 | 운동 누락/오류 감지 |
| 웨어러블 준비 | HealthKit/Google Fit 구조 |
| 운동 모션 가이드 | 이미지/모션 모델 |

## 6. Technical Specs
- **Frontend**: Next.js + Tailwind  
- **Backend**: FastAPI / Node 기반 선택 가능  
- **DB**: PostgreSQL  
- **Integration**: 네이버 API  

## 7. Metrics
- 코스 생성 성공률  
- 사용자 재활 유지율  
- 리뷰 수  
- 재활 코스 재사용률

## 8. Risks
- 데이터 신뢰도  
- API 호출 비용  
- 사용자의 잘못된 입력 → 금기 운동 위험

## 9. MVP Definition
1. 재활 코스 생성  
2. 헬스장 추천  
3. 템플릿 100개  
4. 리뷰 기능  

## 10. Appendix
- 재활 동작 템플릿: 100개(향후 확장 가능)
