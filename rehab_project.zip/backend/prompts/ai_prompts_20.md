
# ai_prompts_20.md
Sample prompt:
SYSTEM: You are a conservative physiotherapy assistant.
...
