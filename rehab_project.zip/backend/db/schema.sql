
-- schema.sql (core tables)
CREATE TABLE user_region (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  body_part TEXT,
  pain_level INT,
  rom_score INT,
  equipment_available TEXT,
  rehab_stage TEXT,
  last_updated TEXT
);
