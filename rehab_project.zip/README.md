
# REHAB Project (Prototype)

This repository contains:
- Multi-region rehab engine prototype
- Database schema
- Templates
- Prompts
- Tests
